//서울기술교육센터 AIOT & Embedded System
//2024-04-16 By KSH

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "esp.h"

static char ip_addr[16]; // ESP 모듈에 할당된 IP 주소를 저장할 배열
static char response[MAX_ESP_RX_BUFFER]; // 응답 저장
//==================uart2=========================
extern UART_HandleTypeDef huart2;
volatile unsigned char rx2Flag = 0;
volatile char rx2Data[50];
uint8_t cdata;

//==================uart6=========================
extern volatile unsigned char rx2Flag;
extern volatile char rx2Data[50];
extern uint8_t cdata; // 터미널 입력한 한 글자를 받아주는 변수
static uint8_t data; // 모듈과 통신하는 변수
cb_data_t cb_data; // 헤더파일의 구조체
sensor_data_t g_sensor_data; // 센서데이터 파일 구조체
extern UART_HandleTypeDef huart6;


int esp_parse_sensor_data(cb_data_t *cb, sensor_data_t *data)
{
	char *sensor_ptr = strstr((char *)cb->buf, "SENSOR@");
	char *heat_ptr = strstr((char *)cb->buf, "SET@HEAT@");
	char *motor_ptr = strstr((char *)cb->buf, "SET@MOTOR@");
	char *dehum_ptr = strstr((char *)cb->buf, "SET@DEHUM@");
	char *model_ptr = strstr((char *)cb->buf, "SET@MODEL@");

	if(sensor_ptr)
	{
		sscanf(sensor_ptr, "SENSOR@%f@%f", &(data->temperature), &(data->humidity));
		return 1;
	}
	else if(heat_ptr)
	{
		sscanf(heat_ptr, "SET@HEAT@%f", &(data->heating_stand));
		return 2;
	}
	else if(motor_ptr)
	{
		sscanf(motor_ptr, "SET@MOTOR@%f", &(data->motor_stand));
		return 3;
	}
	else if(dehum_ptr)
	{
		sscanf(dehum_ptr, "SET@DEHUM@%f", &(data->dehum_stand));
		return 4;
	}
	else if(model_ptr)
	{
		sscanf(model_ptr, "SET@MODEL@%f", &(data->model_humi));
		return 5;
	}

	else
		return -1;
}

void esp_send_sensor_data(sensor_data_t *data)
{
    char buf[200];
    sprintf(buf, "[TARGET]SENSOR@%.1f@%.1f\n",
            data->temperature, data->humidity);
    esp_send_data(buf);
}

static int esp_at_command(uint8_t *cmd, uint8_t *resp, uint16_t *length, int16_t time_out)
{ // AT 명령을 보내고 응답을 기다리는 함수
	// cmd : 전송할 AT명령 문자열, resp : ESP 응답을 저장할 버퍼, length : 길이 저장 포인터, time_out : 응답 대기 시간

	// 버퍼, 구조체 초기화 => 데이터가 남아서 오류가 발생할 수 있음.
	*length = 0;
    memset(resp, 0x00, MAX_UART_RX_BUFFER);
    memset(&cb_data, 0x00, sizeof(cb_data_t));
    if(HAL_UART_Transmit(&huart6, cmd, strlen((char *)cmd), 100) != HAL_OK)
    	// 명령어 송신, 실패 시 -1 반환
        return -1;

    while(time_out > 0)
    {
        if(cb_data.length >= MAX_UART_RX_BUFFER)
            return -2; // 버퍼가 가극 차면 오버플로우
        else if(strstr((char *)cb_data.buf, "ERROR") != NULL)
            return -3; // ERROR 문자열이 포함되면 명령 오류
        else if(strstr((char *)cb_data.buf, "OK") != NULL)
        { // OK(정상작동)일 경우 resp에 복사, 길이 저장 후 0 반환
            memcpy(resp, cb_data.buf, cb_data.length);
            *length = cb_data.length;
            return 0;
        }
        time_out -= 10; // 응답이 없으면 10ms 단위로 대기하면서 time_out 감소
        HAL_Delay(10);
    }
    return -4; // 타임아웃 종료 시 반환
}

static int esp_reset(void) // 모듈 리셋
{
    uint16_t length = 0; // 응답 길이 초기화
    if(esp_at_command((uint8_t *)"AT+RST\r\n", (uint8_t *)response, &length, 1000) != 0)
    {
    	return -1;
    }
    else
    	HAL_Delay(500);	//reboot
    return 0;
    // 응답을 받은 뒤 다음 응답을 위해서 ESP 모듈을 꺠끗하게 만들어 주기 위함
}

static int esp_get_ip_addr(uint8_t is_debug)
// 할당된 IP 주소를 확인하고 가져오는 함수
{
    if(strlen(ip_addr) != 0) // 이미 값이 있다면
    {
        if(strcmp(ip_addr, "0.0.0.0") == 0) // IP가 할당되지 않은 상태
            return -1;
    }
    else
    {
        uint16_t length;
        if(esp_at_command((uint8_t *)"AT+CIPSTA?\r\n", (uint8_t *)response, &length, 1000) != 0)
            printf("ip_state command fail\r\n");
        // IP 확인, 실패시 에러 메세지 출력
        else
        {
            char *line = strtok(response, "\r\n");

            if(is_debug)
            {
                for(int i = 0 ; i < length ; i++)
                    printf("%c", response[i]);
            } // 응답을 UART2터미널로 출력

            while(line != NULL)
            {
                if(strstr(line, "ip:") != NULL) // 문자열 안에서 특정 문자열이 있는지 찾는 함수
                {
                    char *ip;

                    strtok(line, "\""); // 문자열을 특정 구분자 기준으로 나누는 함수
                    ip = strtok(NULL, "\"");
                    if(strcmp(ip, "0.0.0.0") != 0) // IP를 저장한 후 새로운 IP 값을 위해 남아있는 값을 초기화 시켜줌
                    {
                        memset(ip_addr, 0x00, sizeof(ip_addr)); // 초기화
                        memcpy(ip_addr, ip, strlen(ip)); // IP값 저장
                        return 0;
                    }
                }
                line = strtok(NULL, "\r\n");
            }
        }

        return -1; // 실패
    }

    return 0; // 정상
}

static int request_ip_addr(uint8_t is_debug)
{ // 최신 IP를 조회하고 그 결과를 저장

    uint16_t length = 0;

    if(esp_at_command((uint8_t *)"AT+CIFSR\r\n", (uint8_t *)response, &length, 1000) != 0)
        printf("request ip_addr command fail\r\n");
    else
    {
        char *line = strtok(response, "\r\n");

        if(is_debug)
        {
            for(int i = 0 ; i < length ; i++)
                printf("%c", response[i]);
        }

        while(line != NULL)
        {
            if(strstr(line, "CIFSR:STAIP") != NULL)
            {
                char *ip;

                strtok(line, "\"");
                ip = strtok(NULL, "\"");
                if(strcmp(ip, "0.0.0.0") != 0)
                {
                    memset(ip_addr, 0x00, sizeof(ip_addr));
                    memcpy(ip_addr, ip, strlen(ip));
                    return 0;
                }
            }
            line = strtok(NULL, "\r\n");
        }
    }
    return -1;
}
int esp_client_conn()
{
	char at_cmd[MAX_ESP_COMMAND_LEN] = {0, };
	uint16_t length = 0;
	sprintf(at_cmd,"AT+CIPSTART=\"TCP\",\"%s\",%d\r\n",DST_IP,DST_PORT);
	esp_at_command((uint8_t *)at_cmd,(uint8_t *)response, &length, 1000);					//CONNECT

	esp_send_data("["LOGID":"PASSWD"]");
	return 0;
}
int esp_get_status()
{
	uint16_t length = 0;
	esp_at_command((uint8_t *)"AT+CIPSTATUS\r\n",(uint8_t *)response, &length, 1000);					//CONNECT

    if(strstr((char *)response, "STATUS:3") != NULL)  //STATUS:3 The ESP8266 Station has created a TCP or UDP transmission
    {
    	return 0;
    }
	return -1;
}
int drv_esp_init(void)
{
    memset(ip_addr, 0x00, sizeof(ip_addr));
    HAL_UART_Receive_IT(&huart6, &data, 1);

    return esp_reset();
}
void reset_func()
{
	printf("esp reset... ");
	if(esp_reset() == 0)
			printf("OK\r\n");
	else
			printf("fail\r\n");
}

void version_func()
{
  uint16_t length = 0;
  printf("esp firmware version\r\n");
  if(esp_at_command((uint8_t *)"AT+GMR\r\n", (uint8_t *)response, &length, 1000) != 0)
      printf("ap scan command fail\r\n");
  else
  {
      for(int i = 0 ; i < length ; i++)
          printf("%c", response[i]);
  }
}

void ap_conn_func(char *ssid, char *passwd)
{
  uint16_t length = 0;
  char at_cmd[MAX_ESP_COMMAND_LEN] = {0, };
  if(ssid == NULL || passwd == NULL)
  {
      printf("invalid command : ap_conn <ssid> <passwd>\r\n");
      return;
  }
  if(esp_at_command((uint8_t *)"AT+CWMODE=1\r\n", (uint8_t *)response, &length, 1000) != 0)
      printf("Station mode fail\r\n");
  sprintf(at_cmd, "AT+CWJAP=\"%s\",\"%s\"\r\n", ssid,passwd);
  if(esp_at_command((uint8_t *)at_cmd, (uint8_t *)response, &length, 6000) != 0)
      printf("ap scan command fail : %s\r\n",at_cmd);
}

void ip_state_func()
{
  uint16_t length = 0;
  if(esp_at_command((uint8_t *)"AT+CWJAP?\r\n", (uint8_t *)response, &length, 1000) != 0)
      printf("ap connected info command fail\r\n");
  else
  {
      for(int i = 0 ; i < length ; i++)
          printf("%c", response[i]);
  }
  printf("\r\n");

  if(esp_get_ip_addr(1) == 0)
      printf("ip_addr = [%s]\r\n", ip_addr);
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{

    if(huart->Instance == USART6)
    {
        if(cb_data.length < MAX_ESP_RX_BUFFER)
        {
            cb_data.buf[cb_data.length++] = data;
        }

        HAL_UART_Receive_IT(huart, &data, 1);
    }
    if(huart->Instance == USART2)
    {
    	static int i=0;
    	rx2Data[i] = cdata;
    	if(rx2Data[i] == '\r')
    	{
    		rx2Data[i] = '\0';
    		rx2Flag = 1;
    		i = 0;
    	}
    	else
    	{
    		i++;
    	}
    	HAL_UART_Receive_IT(huart, &cdata,1);
    }
}


void AiotClient_Init()
{
//	reset_func();
//	version_func();
	ap_conn_func(SSID,PASS);
//	ip_state_func();
	request_ip_addr(1);
	esp_client_conn();
	esp_get_status();
}

void esp_send_data(char *data)
{
	char at_cmd[MAX_ESP_COMMAND_LEN] = {0, };
	uint16_t length = 0;
	sprintf(at_cmd,"AT+CIPSEND=%d\r\n",strlen(data));
	if(esp_at_command((uint8_t *)at_cmd,(uint8_t *)response, &length, 1000) == 0)
	{
		esp_at_command((uint8_t *)data,(uint8_t *)response, &length, 1000);
	}
}

//==================uart2=========================
int drv_uart_init(void)
{
    HAL_UART_Receive_IT(&huart2, &cdata,1);
    return 0;
}

int drv_uart_tx_buffer(uint8_t *buf, uint16_t size)
{
    if(HAL_UART_Transmit(&huart2, buf, size, 100) != HAL_OK)
        return -1;

    return 0;
}
int __io_putchar(int ch)
{
    if(HAL_UART_Transmit(&huart2, (uint8_t *)&ch, 1, 10) == HAL_OK)
        return ch;
    return -1;
}


